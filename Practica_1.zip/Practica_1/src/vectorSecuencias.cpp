#include "secuencia.h"
#include "vectorSecuencias.h"
#include <iostream>

using namespace std;

    VectorSecuencias::VectorSecuencias(){
        utilizados=0;
    }

    void VectorSecuencias::aniade(SecuenciaCaracteres s){
           if(utilizados < TAMA){
           vector[utilizados++]=s;
           }
    }
    
    int VectorSecuencias::capacidad(){
        return TAMA;
    }
     
    SecuenciaCaracteres VectorSecuencias::secuencia(int indice){
        return vector[indice];
    }
    
    int VectorSecuencias::obtenerUtilizados(){
        return utilizados;
    }

void pintaVector(VectorSecuencias v){
for (int i=0;i<v.obtenerUtilizados();i++){
    pintaSecuencia(v.secuencia(i));
    cout << endl;
}
}

int cuantasPalisimetricas(VectorSecuencias v){
    int contador=0;
    for (int i=0; i<v.obtenerUtilizados(); i++){
        if (v.secuencia(i).esPalisimetrica())
            contador++;
    }
    return contador;
}    