#include "secuencia.h"
#include "vectorSecuencias.h"
#include<iostream>
#include<cstring>
#include<cstdlib>

using namespace std;

int main() {
    // se lee del flujo de entrada
    VectorSecuencias v;
    VectorSecuencias vpal, vnopal;
    bool continuar = true;
    while(continuar){
        string cadena;
        cin >> cadena;
        if(cadena == ""){
            continuar = false;
        }
        else{
             
            // se crea la secuencia
            SecuenciaCaracteres s;
            for(int i=0; i < cadena.length(); i++){
                s.aniade(cadena[i]);
            }
            v.aniade(s);
            
        }
        
    }
    cout << "Secuencias Iniciales"<< endl;
    pintaVector(v); 
    cout << endl;

    for (int i=0; i<v.obtenerUtilizados();i++){
        // se hace la comprobacion
        bool cond = v.secuencia(i).esPalisimetrica();
        if (cond) {
            vpal.aniade(v.secuencia(i));
        } else {
            vnopal.aniade(v.secuencia(i));
        }
    }
    int np = cuantasPalisimetricas(v);
    cout << "Hay "<<  np << " y " << v.obtenerUtilizados()-np << " No Palisimetricas"<<endl;
    
    cout << endl << "Secs Palisimetricas"<<endl;
    pintaVector(vpal);
    cout << endl;
    cout << "Secs No Palisimetricas"<< endl;
    pintaVector(vnopal);
    cout<< endl;
        
    return 0;
}