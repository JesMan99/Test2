#include "secuencia.h"
#include "vectorSecuencias.h"
#include <iostream>

using namespace std;

int SecuenciaCaracteres::contarOcurrencias(char caracter){
   int contador=0;
   for(int i=0; i < utilizados; i++){
       if(v[i] == caracter){
           contador++;
       }
   }

   // devuelve contador
   return contador;
}

SecuenciaCaracteres::SecuenciaCaracteres(){
    // basta con hacer que utilizados sea 0
    utilizados=0;
}

int SecuenciaCaracteres::obtenerUtilizados(){
    return utilizados;
}

int SecuenciaCaracteres::capacidad(){
    return TAMANIO;
}

void SecuenciaCaracteres::aniade(char nuevo){
    // se agrega si hay espacio
    if(utilizados < TAMANIO){
        v[utilizados]=nuevo;
        utilizados++;
    }
}

char SecuenciaCaracteres::elemento(int indice){
    return v[indice];
}

int SecuenciaCaracteres::primeraOcurrencia(char aBuscar){
    int posicion=-1;
    for(int i=0; i < utilizados; i++){
        if(v[i] == aBuscar){
            posicion=i;
        }
    }

    // se devuelve la posicion
    return posicion;
}

SecuenciaCaracteres SecuenciaCaracteres::subsecuencia(int posIni, int posFin){
    SecuenciaCaracteres resultado;

    // solo se trabaja si las posiciones son validas
    if(posFin >= posIni && posIni >= 0 && posIni < utilizados
            && posFin < utilizados){
        // se agregan los caracteres de interes
        for(int i=posIni; i <= posFin; i++){
            resultado.aniade(v[i]);
        }
    }

    // se devuelve el resultado
    return resultado;
}

bool SecuenciaCaracteres::esPalisimetrica(){
    bool resultado=true;

    // se generan dos secuencias: una para cada mitad
    int mitad = utilizados/2;

    // la primera secuencia va desde 0 hasta mitad
    SecuenciaCaracteres primera;
    for(int i=0; i < mitad; i++){
        primera.aniade(v[i]);
    }

    // se determina si la cadena tiene numero para o
    // impar de caracteres para determinar el comienzo
    // de la segunda cadena
    if(utilizados % 2 != 0){
        mitad = mitad+1;
    }

    SecuenciaCaracteres segunda;
    for(int i=mitad; i < utilizados; i++){
        segunda.aniade(v[i]);
    }

    // se genera una secuencia con los caracteres que
    // aparecen en la secuencia, sin repetidos
    SecuenciaCaracteres sinRepetidos;
    for(int i=0; i < utilizados; i++){
        if(sinRepetidos.primeraOcurrencia(v[i]) == -1){
            sinRepetidos.aniade(v[i]);
        }
    }

    // Se recorren ahora los caracteres de la secuencia
    // sin repetidos y se cuentan las apariciones en cada
    // una de las secuencias (para ello se usa un metodo 
    // auxiliar, que consideramos privado)
    for(int i=0; i < sinRepetidos.utilizados && resultado == true; i++){
        int ocurrenciasPrimera = primera.contarOcurrencias(sinRepetidos.v[i]);
        int ocurrenciasSegunda = segunda.contarOcurrencias(sinRepetidos.v[i]);

        // se comprueba la igualdad
        if(ocurrenciasPrimera != ocurrenciasSegunda){
            resultado=false;
        }
    }

    // se deveulve el valor de resultado
    return resultado;
}

void pintaSecuencia(SecuenciaCaracteres s){
    for (int i=0;i<s.obtenerUtilizados();i++)
        cout << s.elemento(i);
    
}