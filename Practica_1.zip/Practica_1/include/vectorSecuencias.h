#ifndef VECTORSECUENCIAS_H
#define VECTORSECUENCIAS_H

#include "secuencia.h"

class VectorSecuencias{
private:
 
    /**
     * Constante para el TAMANIO maximo de las secuencias
     */
    static const int  TAMA=20;
    SecuenciaCaracteres vector[TAMA];
    int utilizados;
    
public:
    
    /* Constructor por defecto
     * crea vector vacio
     */
    VectorSecuencias();
    
    /**
     * Anade una nueva secuencia al vector
     * @param s secuencia a insertar
     */
    void aniade(SecuenciaCaracteres s);
    
    /**
     * Numero máximo de secuencias que se pueden almacenar en el vector
     * @return capacidad
     */
    int capacidad();
            
    /**
     * Devuelva la secuencia en la posicion dada por indice
     * @param indice posicion a consultar
     * @return secuencia en dicha posicion
     * @pre 0 \<= indice \< obtenerUtilizados()
     */
    SecuenciaCaracteres secuencia(int indice);
    
    /**
     * Numero de secuencias insertadas en el vector
     * @return  numero de secuencias en el vector
     */
    int obtenerUtilizados();
    
};

/**
 * muestra un vector de secuencias en la salidad estandar
 * @param v vector a mostrar
 */
void pintaVector(VectorSecuencias v);

/**
 * Cuenta el numero de secuencias palisimetricas en el vector
 * @param v el vector
 * @return numero de secs palisimetricas en v
 */
int cuantasPalisimetricas(VectorSecuencias v);

#endif /* VECTORSECUENCIAS_H */